import "./styles.css";
 
document.getElementById("app").innerHTML = `
<h1></h1>
<div>
</div>
`;
